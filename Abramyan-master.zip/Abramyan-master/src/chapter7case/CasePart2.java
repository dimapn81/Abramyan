package chapter7case;

//case 10 - 20;

public class CasePart2 {

	
	public static void main(String[] args) {

		
	}

}
